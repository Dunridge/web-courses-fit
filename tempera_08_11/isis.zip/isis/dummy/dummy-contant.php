


<div class="our_work">
        <div class="title">
          <h2 class="blue">Наши работы</h2>
        </div>
        <div id="middle" class="cols2 sidebar_left box_white">
          <div class="content" role="main">
            <article class="post-detail">
              <div class="entry">
                <div class="work-carousel">
                  <div class="work-carousel-head"> <a class="prev" id="work-carousel-prev" href="#" ><span>prev</span></a> <a class="next" id="work-carousel-next" href="#"><span>next</span></a> </div>
                  <div class="carousel_content">
                    <div class="caroufredsel_wrapper" >
                      <ul id="work-carousel" >
                        <li>
                          <div class="work">
                            <div class="main">
                           
                              <div class="view view-seventh"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/bg2.png" alt="<?php the_title_attribute(); ?>" />
                            
                                <div class="mask">
                               
                                  <h2>Beautiful Photo</h2>
                                 
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy.</p>
                                  <a href="<?php echo of_get_option('recenturl1'); ?>" class="info">Подробнее</a> </div>
                              </div>
                            </div>
                            <p class="port">Beautiful Photo</p>
                          </div>
                        </li>
                        <li>
                          <div class="work">
                            <div class="main">
                              
                              <div class="view view-seventh"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/bg4.png" alt="<?php the_title_attribute(); ?>" />
                              
                               <div class="mask">
                               
                                  <h2>Beautiful Photo</h2>
                                 
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy.</p>
                                  <a href="<?php echo of_get_option('recenturl2'); ?>" class="info">Подробнее</a> </div>
                              </div>
                            </div>
                            <p class="port">Beautiful Photo</p>
                          </div>
                        </li>
                        <li>
                          <div class="work">
                            <div class="main">
                              
                              <div class="view view-seventh"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/bg2.png" alt="<?php the_title_attribute(); ?>" />
                              
                               <div class="mask">
                               
                                  <h2>Beautiful Photo</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy.</p>
                                  <a href="<?php echo of_get_option('recenturl3'); ?>" class="info">Подробнее</a> </div>
                              </div>
                            </div>
                            <p class="port">Beautiful Photo</p>
                          </div>
                        </li>
                        <li >
                          <div class="work">
                            <div class="main">
                              
                              <div class="view view-seventh"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/bg5.png" alt="<?php the_title_attribute(); ?>" />
                              
                               <div class="mask">
                              
                                  <h2>Beautiful Photo</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy.</p>
                                  <a href="<?php echo of_get_option('recenturl4'); ?>" class="info">Подробнее</a> </div>
                              </div>
                            </div>
                            <p class="port">Beautiful Photo</p>
                          </div>
                        </li>
                        <li >
                         <div class="work">
                            <div class="main">
                              
                              <div class="view view-seventh"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/bg2.png" alt="<?php the_title_attribute(); ?>" />
                              
                               <div class="mask">
                               
                                  <h2>Beautiful Photo</h2>
                            
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy.</p>
                                  <a href="<?php echo of_get_option('recenturl4'); ?>" class="info">Подробнее</a> </div>
                              </div>
                            </div>
                           
                            <p class="port">Beautiful Photo</p>
                          </div>
                        </li>
                       
                         
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </article>
            </div></div>