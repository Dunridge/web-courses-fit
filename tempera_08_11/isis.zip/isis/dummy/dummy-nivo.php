
           
 <div id="nivo" class="nivoSlider">
                
                
                
                <img title="#nv_1" src="<?php echo get_template_directory_uri(); ?>/images/demo/slide2.jpg"  alt="" data-transition="slideInLeft" />
				 <img title="#nv_2" src="<?php echo get_template_directory_uri(); ?>/images/demo/slide1.jpg"  alt="" data-transition="slideInLeft" />
                
                <a href="<?php echo esc_url( home_url( '/' ) );?>"><img src="<?php echo get_template_directory_uri(); ?>/images/slides/slide3.jpg" alt="You can also add Links to your slides" title="#nv_3"/></a>
            
              
            </div>
             
           
			 
			  <div id="nv_1" class="nivo-html-caption">          
            <h3 class="entry-title">We Work Efficiently</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus.</p>
            </div>
			
			  <div id="nv_2" class="nivo-html-caption">          
            <h3 class="entry-title">24/7 Live Support</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus.</p>
            </div>