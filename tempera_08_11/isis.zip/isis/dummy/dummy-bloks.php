<div class="midrow">

 <div class="midrow_wrap">       
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
         <i class="fa fa-heart fa-3x icon"></i> 
        
        <div class="midrow_block">
        <div class="mid_block_content">
        <h3>We Work Efficiently</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
    
        </div>
          <a  class="blocklink"></a>
        </div></div>
         <div class="shadow"><img  src="<?php echo get_template_directory_uri(); ?>/images/service_shadow.png" alt="<?php the_title_attribute(); ?>" /></div>
       
        </div>
        
         
     
            
        <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
        <i class="fa fa-volume-up fa-3x icon"></i>
        
        <div class="midrow_block">
        
        <div class="mid_block_content">
        <h3>24/7 Live Support</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac. Sed ultrices leo.</p>
     
        </div>
       <a  class="blocklink"></a>
        </div></div>
        <div class="shadow"><img  src="<?php echo get_template_directory_uri(); ?>/images/service_shadow.png" alt="<?php the_title_attribute(); ?>" /></div>
        
        </div>
      
        
        
         <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
        <i class="fa fa-fighter-jet fa-3x icon"></i>
        
       
        <div class="midrow_block">
        
        <div class="mid_block_content">
        <h3>Confide</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac. </p>
    
        </div>
        <a  class="blocklink"></a>
        </div></div>
        <div class="shadow"><img  src="<?php echo get_template_directory_uri(); ?>/images/service_shadow.png" alt="<?php the_title_attribute(); ?>" /></div>
        
        </div>
        
         
         
         <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
        <i class="fa fa-cogs fa-3x icon"></i>
         
     
        <div class="mid_block_content">
        
        <h3>Gurantee Like No Other</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum.</p>
     
        </div>
      <a  class="blocklink"></a>
        </div>
        <div class="shadow"><img  src="<?php echo get_template_directory_uri(); ?>/images/service_shadow.png" alt="<?php the_title_attribute(); ?>" /></div>
       