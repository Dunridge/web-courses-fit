 <div class="clients">
        <div class="title">
          <h2 class="green"><?php echo of_get_option('our_client'); ?></h2>
        </div>
        <div class="client"> <a href="<?php echo of_get_option('clienturl1'); ?>"><img  src="<?php echo of_get_option('client1'); ?>" alt="" /> </a> </div>
        
         <div class="client"> <a href="<?php echo of_get_option('clienturl2'); ?>"><img  src="<?php echo of_get_option('client2'); ?>" alt="" /> </a></div> 
       
    
    <div class="client"> <a href="<?php echo of_get_option('clienturl3'); ?>"><img  src="<?php echo of_get_option('client3'); ?>" alt="" /> </a> </div> 



 <div class="client"> <a href="<?php echo of_get_option('clienturl4'); ?>"><img  src="<?php echo of_get_option('client4'); ?>" alt="" /> </a> 
</div>
      </div>
    </div>
  </div>