<!--MIDROW STARTS-->

<div class="midrow">

 <div class="midrow_wrap">  
 <?php if ( of_get_option('block1_text') ) { ?>     
           
        <div class="style3 midrow_blocks_wrap"> 
        <div class="article-in ">
        <div class="icon-cog-1">
         
        <i class="fa <?php echo of_get_option('block1_logo'); ?> fa-3x icon"></i>
     </div>
        
       
        <h2><?php echo of_get_option('block1_text'); ?></h2>
        <div class="just-content">
        <p><?php echo of_get_option('block1_textarea'); ?></p>
    
       
         <?php if ( of_get_option('block1_link') ) { ?><a <?php if(of_get_option('newtab_checkbox','hathor') == "1"){ ?> target="_blank" <?php } ?> href="<?php echo of_get_option('block1_link'); ?>" class="midbutton2"><?php echo of_get_option('servicelink2'); ?></a><?php } ?>
        </div>
        
        
        </div>
        
       </div>

        
        
         
        <?php } ?>
        
        
<?php if ( of_get_option('block2_text') ) { ?>     
           
        <div class="style3 midrow_blocks_wrap"> 
        <div class="article-in ">
        <div class="icon-cog-1">
         
        <i class="fa <?php echo of_get_option('block2_logo'); ?> fa-3x icon"></i>
     </div>
        
       
        <h2><?php echo of_get_option('block2_text'); ?></h2>
        <div class="just-content">
        <p><?php echo of_get_option('block2_textarea'); ?></p>
    
       
         <?php if ( of_get_option('block2_link') ) { ?><a <?php if(of_get_option('newtab_checkbox','hathor') == "1"){ ?> target="_blank" <?php } ?> href="<?php echo of_get_option('block2_link'); ?>" class="midbutton2"><?php echo of_get_option('servicelink2'); ?></a><?php } ?>
        </div>
        
        
        </div>
        
       </div>

        
        
         
        <?php } ?>

<?php if ( of_get_option('block3_text') ) { ?>     
           
        <div class="style3 midrow_blocks_wrap"> 
        <div class="article-in ">
        <div class="icon-cog-1">
         
        <i class="fa <?php echo of_get_option('block3_logo'); ?> fa-3x icon"></i>
     </div>
        
       
        <h2><?php echo of_get_option('block3_text'); ?></h2>
        <div class="just-content">
        <p><?php echo of_get_option('block3_textarea'); ?></p>
    
       
         <?php if ( of_get_option('block3_link') ) { ?><a <?php if(of_get_option('newtab_checkbox','hathor') == "1"){ ?> target="_blank" <?php } ?> href="<?php echo of_get_option('block3_link'); ?>" class="midbutton2"><?php echo of_get_option('servicelink2'); ?></a><?php } ?>
        </div>
        
        
        </div>
        
       </div>

        
        
         
        <?php } ?>
        
<?php if ( of_get_option('block4_text') ) { ?>     
           
        <div class="style3 midrow_blocks_wrap"> 
        <div class="article-in ">
        <div class="icon-cog-1">
         
        <i class="fa <?php echo of_get_option('block4_logo'); ?> fa-3x icon"></i>
     </div>
        
       
        <h2><?php echo of_get_option('block4_text'); ?></h2>
        <div class="just-content">
        <p><?php echo of_get_option('block4_textarea'); ?></p>
    
       
         <?php if ( of_get_option('block4_link') ) { ?><a <?php if(of_get_option('newtab_checkbox','hathor') == "1"){ ?> target="_blank" <?php } ?> href="<?php echo of_get_option('block4_link'); ?>" class="midbutton2"><?php echo of_get_option('servicelink2'); ?></a><?php } ?>
        </div>
        
        
        </div>
        
       </div>

        
        
         
        <?php } ?>
  
         
        </div>
        
        
        </div>
     </div>   
</div>
 
        
   



<!--MIDROW END-->
  
        
             
          
     

   

</div>