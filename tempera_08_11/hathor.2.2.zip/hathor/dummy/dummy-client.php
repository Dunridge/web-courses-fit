<div class="row ">
<div class=" warp large-12 columns">

 <div class="clients">
        <div class="title">
          <h2 class="green1">Our Client</h2>
        </div>
        
        
        <div class="work-carousel">
              <div class="work-carousel-head"> <a class="prev" id="work-carousel-prev2" href="#" ><span>prev</span></a> <a class="next" id="work-carousel-next2" href="#"><span>next</span></a> </div>    
        <div class="carousel_content">
        <div class="caroufredsel_wrapper" >
        <ul id="work-carousels" >
        <li>
        <div class="client"> <a href="#"><img  src="<?php echo get_template_directory_uri(); ?>/images/demo/logo1.png" alt="" /> </a> </div></li>
        <li>
         <div class="client"> <a href="#"><img  src="<?php echo get_template_directory_uri(); ?>/images/demo/logo2.png" alt="" /> </a></div> </li>
       
    <li>
    <div class="client"> <a href="#"><img  src="<?php echo get_template_directory_uri(); ?>/images/demo/logo3.png" alt="" /> </a> </div> 
</li>

<li>
 <div class="client"> <a href="#"><img  src="<?php echo get_template_directory_uri(); ?>/images/demo/logo4.png" alt="" /> </a>
</div></li>
<li>
 <div class="client"> <a href="#"><img  src="<?php echo get_template_directory_uri(); ?>/images/demo/logo1.png" alt="" /> </a>
</div></li>

</ul></div>
      </div>
    </div>
  </div></div></div>