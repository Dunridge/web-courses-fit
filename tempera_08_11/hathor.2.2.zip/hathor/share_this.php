<div class="social-profiles clearfix">
				
                <ul>
				

        <li class="facebook"> <a href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;amp;t=<?php echo urlencode(the_title('','', false)) ?>" title="Share <?php _e('this post on Facebook', 'hathor');?>">facebook</a></li>
         
               
                <li class="twitter"><a href="http://twitter.com/home?status=Reading: <?php the_title(); ?> <?php the_permalink();?>" title="Tweet <?php _e('this post', 'hathor'); ?>">Twitter</a></li>
                
               
                <li class="google-plus"> <a title="Plus One <?php _e('This', 'hathor'); ?>" href="https://plusone.google.com/_/+1/confirm?hl=en&url=<?php echo the_permalink(); ?>">Google +1</a></li>
                
              
                <li class="pinterest"><a href='javascript:void((function()%7Bvar%20e=document.createElement(&apos;script&apos;);e.setAttribute(&apos;type&apos;,&apos;text/javascript&apos;);e.setAttribute(&apos;charset&apos;,&apos;UTF-8&apos;);e.setAttribute(&apos;src&apos;,&apos;http://assets.pinterest.com/js/pinmarklet.js?r=&apos;+Math.random()*99999999);document.body.appendChild(e)%7D)());'>Pinterest</a></li>
             
                
                
               
                
			</ul>
			</div>