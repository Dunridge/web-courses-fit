<?php

/**
 * Main class for pages
 *
 * @author 	Gijs Jorissen
 * @since 	1.3
 *
 */

class Cuztom_Page
{
	var $page_title;
	var $menu_title;
	var $capability;
	var $menu_slug;
	var $function;
}