<?php

class Cuztom_Bundle
{
	var $id;
	var $fields = array();
}