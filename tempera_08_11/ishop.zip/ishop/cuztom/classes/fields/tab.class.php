<?php

class Cuztom_Tab
{
	var $id;
	var $fields = array();
}