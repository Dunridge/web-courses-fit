<?php

class Cuztom_Accordion
{
	var $id;
	var $tabs = array();
}