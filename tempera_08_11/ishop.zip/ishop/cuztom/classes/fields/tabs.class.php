<?php

class Cuztom_Tabs
{
	var $id;
	var $tabs = array();
}