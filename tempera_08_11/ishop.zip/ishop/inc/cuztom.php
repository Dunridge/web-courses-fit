<?php

/* Adds the Product post type */
$products  = new Cuztom_Post_Type( 'Products', array(
    'has_archive' => true,
    'taxonomies' => array( 'category' ),
    'supports' => array( 'title', 'editor', 'thumbnail' )
) );



/* Adds metaboxes to products */

$products->add_meta_box(
   'Product info',
    array(
    
    array(
        'name'          => 'product_price',
        'label'         => 'Цена товара',
        'description'   => 'Укажите цену товара',
        'type'          => 'text',
    ),
     array(
        'name'          => 'product_description',
        'label'         => 'Описание товара',
        'description'   => 'Небольшое описание товара',
        'type'          => 'textarea',
    )
       
    
    ));
    
    
    
function add_custom_taxonomies() {

	register_taxonomy('department', 'products', array(
		// Hierarchical taxonomy (like categories)
		'hierarchical' => true,
		// This array of options controls the labels displayed in the WordPress Admin UI
		'labels' => array(
			'name' => _x( 'Рубрика товаров', 'taxonomy general name' ),
			'singular_name' => _x( 'Рубрика', 'taxonomy singular name' ),
			'search_items' =>  __( 'Поиск рубрики' ),
			'all_items' => __( 'Все рубрики' ),
			'parent_item' => __( 'Основная рубрика' ),
			'parent_item_colon' => __( 'Основная рубрика:' ),
			'edit_item' => __( 'Редактировать рубрику' ),
			'update_item' => __( 'Обновить рубрику' ),
			'add_new_item' => __( 'Добавить рубрику' ),
			'new_item_name' => __( 'Новое название рубрики' ),
			'menu_name' => __( 'Рубрики товаров' ),
		),
		// Control the slugs used for this taxonomy
		'rewrite' => array(
			'slug' => 'department', // This controls the base slug that will display before each term
			'with_front' => false, // Don't display the category base before "/locations/"
			'hierarchical' => true // This will allow URL's like "/locations/boston/cambridge/"
		),
	));
}
add_action( 'init', 'add_custom_taxonomies', 0 );    


    
function cart66_popup_screens() { 
    return array('products');
  }  
 add_filter('cart66_add_popup_screens', 'cart66_popup_screens');