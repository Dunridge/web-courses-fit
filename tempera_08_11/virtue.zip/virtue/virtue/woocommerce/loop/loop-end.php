<?php
/**
 * Product Loop End
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
</div>
	<script type="text/javascript">
             jQuery( window ).load(function () {	
             	var $container = jQuery('#product_masonry');
					// initialize
					$container.masonry({
					  itemSelector: '.product_item'
					});
				});
					</script>