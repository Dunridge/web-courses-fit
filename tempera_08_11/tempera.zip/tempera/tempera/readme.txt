Tempera Theme for WordPress
by Cryout Creations

Theme created by Cryout Creations - www.cryoutcreations.eu
Theme support www.cryoutcreations.eu/tempera

The Tempera Theme and ALL included binaries (all images and patterns) are released under the GPLv3 licence. Please read the included license.txt for the full licence.

The Tempera Theme uses:
- Nivo Slider by Gilbert Pellegrom / under the MIT license / http://nivo.dev7studios.com/
- tinyNav by @viljamis / under the MIT license / http://tinynav.viljamis.com/
- FitVids by Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com

The extra fonts incuded with the theme are also under GPLv3 compatible licences as follows:
- Ubuntu - SIL Open Font License v1.1
- Sans Droid - Apache License v2.00
- Oswald -  SIL Open Font License 1.1
- Open Sans - Apache License v2.0
- Bebas Neue -  SIL Open Font License 1.1
- Yanone Kaffeesatz - SIL Open Font License 1.1
- Elusive icon font - SIL Open Font License 1.1
- Fontawesome icon font - SIL Open Font License 1.1

Translations credits:
