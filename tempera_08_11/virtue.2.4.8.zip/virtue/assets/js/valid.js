// JavaScript Document
$(document).ready(function(){
	$("#contactForm").validate();
});